Folder "web": HTML/JS build of the game.
Exe: Windows 64 bit executable