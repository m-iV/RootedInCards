How to Build:
Download Godot 4 Beta 17 (Almost any version of Godot 4 will work but I used Beta 17)
Open the Project
If you want to run in-editor: Hit F5
Else:
	Project->Export
	Install the build templates
	Export what you want to build